import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-professionals',
  templateUrl: './professionals.component.html',
  styleUrls: ['./professionals.component.css']
})
export class ProfessionalsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
